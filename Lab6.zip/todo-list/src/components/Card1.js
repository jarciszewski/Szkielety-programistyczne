export const Card1 = ()=>{
    return(
        <div className="Card">
            <h2>Alan Turing</h2>
            <img src="https://mdz.cs.pollub.pl/ai/alan_turing.jpg" alt="Alan Turing" />
            <p>1912 - 1954</p>
            <p>Matematyk</p>
            <p>Angilia</p>
        </div>
    )
}