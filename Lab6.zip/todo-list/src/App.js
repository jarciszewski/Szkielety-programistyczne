import './Card.css'
import { Card } from './components/Card'
import { infTab } from './data/infTab'

function App() {
  return (
    <div>
      <h1>Słynni informatycy</h1>
      {infTab.map((element, index)=>{
        return <Card
        props = {element}
        key = {index}/>
      })}
    </div>
  )
}
export default App