export const MainArea = ({props})=>{
    return(
        <div className="main-area" style={{color: props.currentValues.color, fontSize: props.currentValues.fontSize}}>
        <h2>Główna część strony</h2>
        <p>
          Szkielety programistyczne w aplikacjach internetowych: Node, MongoDB, Express, React.
        </p>
      </div>
    )
}