const express = require('express')
const path = require('path')
const app = express()
const PORT = 3000
const { check, validationResult } = require('express-validator')

const data = require('C:/Users/kasaks/Desktop/lab 4/users.js')

app.get('/api/users', (req,res) => {
    
    res.json(data)
})

app.listen(PORT, () => console.log(`Serwer działa na porcie ${PORT}`))