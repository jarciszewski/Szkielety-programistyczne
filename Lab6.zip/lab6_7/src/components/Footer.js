export const Footer = ({props})=>{
    return(
        <footer className="footer">
            <p>
            Stopka{" "}<br/>
            <button onClick={()=>props.setCurrentValues({...props.currentValues, fontSize:"30px"})}>
                Ustaw parametry tekstu na 30px, a kolor pozostaw bez zmian
            </button>
            </p>
            <p>
            <button onClick={()=>props.setLikes(props.likes+1)}>Polub tę stronę!</button>
            </p>
        </footer>
    )
}