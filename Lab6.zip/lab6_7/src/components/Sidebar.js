export const Sidebar = ({props})=>{
    return(
        <div className="sidebar">
            <h2>Pasek Boczny</h2>
            <input type="text" onChange={(e)=>props.setFontSize(e.target.value + "px")} />
            <input type="text" onChange={(e)=>props.setColor(e.target.value)}/>
            <button onClick={()=>props.setCurrentValues({fontSize: props.fontSize, color: props.color})}>Ustaw parametry</button>
        </div>
    )
}