const express = require('express')
const path = require('path')
const app = express()
const PORT = 3000
const { check, validationResult } = require('express-validator')

app.get("/form", (req, res) => {
    res.sendFile(path.join(__dirname, "form.html"))
})

const sanitizeValue = value => {
    
}

app.post("/post", [
    check('nazwisko').isLength({ min: 3, max: 25 }),
    check('email').isEmail(),
    check('wiek').isNumeric()
], (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
        return res.status(422).json({ errors: errors.array() })
    }
    const nazwisko = req.body.nazwisko
    const email = req.body.email
    const wiek = req.body.wiek
    res.send("Użytkownik: " + nazwisko + "<br>Email: " + email + "<br>Wiek: " + wiek)
})

app.listen(PORT, () => console.log(`Serwer działa na porcie ${PORT}`))