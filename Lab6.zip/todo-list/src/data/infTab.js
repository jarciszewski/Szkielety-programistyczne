export const infTab = [{
    name: "Alan Turing",
    img: "https://mdz.cs.pollub.pl/ai/alan_turing.jpg",
    lifetime: "1912 - 1954",
    job: "Matematyk",
    country: "Anglia"
  },
  {
    name: "Niklaus Wirth",
    img: "https://mdz.cs.pollub.pl/ai/nicolas_wirth.jpg",
    lifetime: "1934 - ?",
    job: "Elektronik i informatyk",
    country: "Szwajcaria"
  },
  {
    name: "Dennis Ritchie",
    img: "https://mdz.cs.pollub.pl/ai/nicolas_wirth.jpg",
    lifetime: "1934 - ?",
    job: "Elektronik i informatyk",
    country: "Szwajcaria"
    }
]