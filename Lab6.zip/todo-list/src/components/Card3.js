export const Card3 = ()=>{
    return(
        <div className="Card">
            <h2>Dennis Ritchie</h2>
            <img src="https://mdz.cs.pollub.pl/ai/dennis_ritchie.jpg" alt="Dennis Ritchie" />
            <p>1941 - 2011</p>
            <p>Matematyk, fizyk, informatyk</p>
            <p>USA</p>
        </div>
    )
}