import "./FaqElement.css"
const FaqElement = (props) => {
    return (
        <li className="faq-element">
            <h2 className="question">{props.question}</h2>
            <p>{props.answer}</p>
        </li>
    )
}

import PropTypes from "prop-types"
FaqElement.propTypes = {
    question: PropTypes.string.isRequired,
    answer: PropTypes.string.isRequired,
}

export default FaqElement