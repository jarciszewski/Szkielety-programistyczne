export const Card2 = ()=>{
    return(
        <div className="Card">
            <h2>Niklaus Wirth</h2>
            <img src="https://mdz.cs.pollub.pl/ai/nicolas_wirth.jpg" alt="Niklaus Wirth" />
            <p>1934 - ?</p>
            <p>Elektronik i informatyk</p>
            <p>Szwajcaria</p>
        </div>
    )
}