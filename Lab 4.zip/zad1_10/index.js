const express = require('express')
const path = require('path')
const app = express()
const PORT = 3000

let urlencodedParser = express.urlencoded({ extended: true })

app.get("/form", (req, res) => {
    res.sendFile(path.join(__dirname, "form.html"))
})

app.post("/result", urlencodedParser, (req, res) => {
    response = {
        username: req.body.username,
        password: req.body.password
    }
    if (!response.username || !response.password) {
        res.send("Uzupełnij dane!")
    }
    else {
        res.end(JSON.stringify(response))
    }
})

app.listen(PORT, () => console.log(`Serwer działa na porcie ${PORT}`))