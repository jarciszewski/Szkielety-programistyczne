export const Card = ({props})=>{
    return (
        <div className="Card">
            <h2>{props.name}</h2>
            <img src={props.img} alt="Alan Turing" />
            <p>{props.lifetime}</p>
            <p>{props.job}</p>
            <p>{props.country}</p>
        </div>
    )
}