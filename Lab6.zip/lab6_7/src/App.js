import "./App.css"
import React from "react"
import {useState} from "react"

import { Header } from "./components/Header"
import { Sidebar } from "./components/Sidebar"
import { MainArea } from "./components/MainArea"
import { Footer } from "./components/Footer"

function App() {
  const [fontSize, setFontSize] = useState("18px")
  const [color, setColor] = useState("green")
  const [likes, setLikes] = useState(0)

  const [currentValues, setCurrentValues] = useState({
    fontSize: "18px",
    color: "green"
  })
  
  return (
    <div className="grid-parent">
      <Header
        props={{fontSize, color, likes}}
      />
      <Sidebar
        props={{setFontSize, setColor, setCurrentValues, currentValues, fontSize, color,}}
      />
      <MainArea
        props={{setCurrentValues, currentValues}}
      />
      <Footer
        props={{setCurrentValues, currentValues, setLikes, likes}}
      />
    </div>
  );
}
export default App;
